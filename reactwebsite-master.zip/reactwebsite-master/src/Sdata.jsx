import web from '../src/images/s1.jpg'
import app from '../src/images/s2.jpg'
import android from '../src/images/s3.jpg'
import digital from '../src/images/s4.jpg'
import marketing from '../src/images/s5.jpg'
import software from '../src/images/s6.jpg'


const Sdata=[
    {
        imgsrc:web,
        title:"Web developnment"
    },
    {
        imgsrc:app,
        title:"App developnment"
    },
    {
        imgsrc:android,
        title:"Android developnment"
    },
    {
        imgsrc:digital,
        title:"digital marketing"
    },
    {
        imgsrc:marketing,
        title:"marketing"
    },
    {
        imgsrc:software,
        title:"software developnment"
    },
]
export default Sdata;